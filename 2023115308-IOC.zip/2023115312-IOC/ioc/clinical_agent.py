"""
Clinical Workflow Automation Agent
Uses function calling to interact with healthcare APIs
"""
import json
import os
import re
from typing import List, Dict, Any, Optional
import requests
from agent_functions import get_agent_functions, execute_function
from audit_logger import audit_logger
from config import HF_API_KEY, DRY_RUN_MODE


class ClinicalAgent:
    """
    Clinical workflow automation agent using function calling
    """
    
    def __init__(self, dry_run: bool = None):
        self.dry_run = dry_run if dry_run is not None else DRY_RUN_MODE
        self.functions = get_agent_functions()
        self.hf_api_key = HF_API_KEY
        self.api_url = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2"
        
    def _call_llm_with_functions(self, messages: List[Dict[str, Any]], 
                                 available_functions: List[Dict]) -> Dict[str, Any]:
        """
        Call Hugging Face Inference API with function calling support
        Using a structured approach to simulate function calling
        """
        # Format system message with function definitions
        system_prompt = """You are a clinical workflow automation agent. Your role is to:
1. Understand clinical or administrative requests
2. Call appropriate functions to retrieve information or perform actions
3. NEVER provide medical diagnosis or advice
4. Always validate patient information before actions
5. Provide structured, auditable responses

Available functions:
"""
        for func in available_functions:
            func_def = func["function"]
            system_prompt += f"\n- {func_def['name']}: {func_def['description']}\n"
            system_prompt += f"  Parameters: {json.dumps(func_def['parameters'], indent=2)}\n"
        
        system_prompt += """
When you need to call a function, respond with JSON in this format:
{
  "function_calls": [
    {
      "function_name": "function_name",
      "arguments": {"param1": "value1"}
    }
  ],
  "reasoning": "Brief explanation of why these functions are needed"
}

After function results are provided, synthesize the final answer.
"""
        
        # Build the prompt
        full_prompt = system_prompt + "\n\nUser request:\n" + messages[-1]["content"]
        
        headers = {
            "Authorization": f"Bearer {self.hf_api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "inputs": full_prompt,
            "parameters": {
                "max_new_tokens": 512,
                "temperature": 0.1,
                "return_full_text": False
            }
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()
            
            # Handle response format
            if isinstance(result, list) and len(result) > 0:
                text = result[0].get("generated_text", "")
            else:
                text = str(result)
            
            return {"text": text, "function_calls": self._extract_function_calls(text)}
        except requests.exceptions.RequestException as e:
            # Fallback: Use a simpler approach
            return self._simple_llm_fallback(messages, available_functions)
    
    def _extract_function_calls(self, text: str) -> List[Dict[str, Any]]:
        """Extract function calls from LLM response"""
        function_calls = []
        
        # Try to parse JSON function calls
        try:
            # Look for JSON objects in the response
            import re
            json_matches = re.findall(r'\{[^{}]*"function_calls"[^{}]*\}', text, re.DOTALL)
            for match in json_matches:
                parsed = json.loads(match)
                if "function_calls" in parsed:
                    function_calls.extend(parsed["function_calls"])
        except:
            pass
        
        return function_calls
    
    def _simple_llm_fallback(self, messages: List[Dict[str, Any]], 
                            available_functions: List[Dict]) -> Dict[str, Any]:
        """
        Rule-based function calling when LLM API is unavailable
        This demonstrates the deterministic nature of function calling
        """
        import re
        user_input = messages[-1]["content"]
        user_lower = user_input.lower()
        function_calls = []
        
        # Extract patient name for search
        patient_name = None
        name_patterns = [
            r'(?:patient|for)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'schedule.*?for\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'([A-Z][a-z]+\s+[A-Z][a-z]+)(?:\s+.*?)?(?:appointment|follow-up|eligibility)'
        ]
        for pattern in name_patterns:
            match = re.search(pattern, user_input, re.IGNORECASE)
            if match:
                patient_name = match.group(1)
                break
        
        # Extract department
        department = None
        dept_patterns = [
            r'(cardiology|orthopedic|orthopedics|general\s+medicine|pediatrics|dermatology)',
            r'(\w+)\s+(?:follow-up|appointment|consultation)'
        ]
        for pattern in dept_patterns:
            match = re.search(pattern, user_lower, re.IGNORECASE)
            if match:
                dept = match.group(1).title()
                if "orthopedic" in dept.lower():
                    dept = "Orthopedics"
                elif "general" in dept.lower():
                    dept = "General Medicine"
                department = dept
                break
        
        # Determine which functions to call based on keywords
        needs_patient_search = ("patient" in user_lower or "search" in user_lower) and patient_name
        needs_insurance_check = "insurance" in user_lower or "eligibility" in user_lower
        needs_slots = ("appointment" in user_lower or "slot" in user_lower or "schedule" in user_lower) and department
        needs_booking = "book" in user_lower or ("schedule" in user_lower and "and" not in user_lower[-20:])
        
        # Add function calls in logical order
        if needs_patient_search:
            function_calls.append({
                "function_name": "search_patient",
                "arguments": {"name": patient_name}
            })
        
        # Note: Insurance check would need patient_id from search result
        # This is a simplified version - in practice, you'd chain function calls
        
        if needs_slots:
            function_calls.append({
                "function_name": "find_available_slots",
                "arguments": {"department": department or "Cardiology"}
            })
        
        # Booking would typically happen after getting patient_id and slot_id
        # This is simplified for the demo
        
        return {
            "text": "Analyzing request and determining required functions...",
            "function_calls": function_calls
        }
    
    def process_request(self, user_input: str, context: Optional[str] = None) -> Dict[str, Any]:
        """
        Process a user request through the agent
        
        Args:
            user_input: Natural language request from user
            context: Optional context information
            
        Returns:
            Dictionary with agent response and execution details
        """
        # Safety check: Refuse medical advice requests
        medical_advice_keywords = [
            "diagnose", "diagnosis", "what's wrong", "what disease", 
            "treatment for", "medication for", "should I take", "is this normal"
        ]
        user_lower = user_input.lower()
        
        if any(keyword in user_lower for keyword in medical_advice_keywords):
            response = {
                "status": "refused",
                "message": "I cannot provide medical diagnosis or advice. I can only help with administrative tasks like scheduling appointments, checking eligibility, and patient lookups.",
                "function_calls": []
            }
            audit_logger.log_agent_interaction(
                user_input, response["message"], [], context
            )
            return response
        
        # Prepare messages for LLM
        messages = [{"role": "user", "content": user_input}]
        
        # Get function calls from LLM (or fallback)
        llm_response = self._call_llm_with_functions(messages, self.functions)
        function_calls = llm_response.get("function_calls", [])
        
        # If no function calls found, try enhanced fallback
        if not function_calls:
            llm_response = self._simple_llm_fallback(messages, self.functions)
            function_calls = llm_response.get("function_calls", [])
        
        # Execute functions sequentially, allowing chaining
        execution_results = []
        patient_id_from_search = None
        
        for func_call in function_calls:
            func_name = func_call.get("function_name")
            func_args = func_call.get("arguments", {}).copy()
            
            # Chain function calls: if insurance check is needed and we have patient_id
            if func_name == "check_insurance_eligibility" and not func_args.get("patient_id") and patient_id_from_search:
                func_args["patient_id"] = patient_id_from_search
            
            # Execute the function
            result = execute_function(func_name, func_args, dry_run=self.dry_run)
            execution_results.append(result)
            
            # Extract patient_id from search result for chaining
            if func_name == "search_patient" and result.get("status") == "success":
                result_data = result.get("result", {})
                patients = result_data.get("patients", [])
                if patients:
                    patient_id_from_search = patients[0].get("patient_id")
            
            # Log the function call
            audit_logger.log_function_call(
                func_name, func_args, result, user_input
            )
        
        # Handle multi-step requests (e.g., search patient then check insurance)
        # If user asks for insurance but we didn't call it yet, add it now
        if ("insurance" in user_lower or "eligibility" in user_lower) and patient_id_from_search:
            # Check if insurance was already checked
            insurance_checked = any(
                r.get("function_name") == "check_insurance_eligibility" 
                for r in execution_results
            )
            if not insurance_checked:
                result = execute_function(
                    "check_insurance_eligibility", 
                    {"patient_id": patient_id_from_search},
                    dry_run=self.dry_run
                )
                execution_results.append(result)
                audit_logger.log_function_call(
                    "check_insurance_eligibility", 
                    {"patient_id": patient_id_from_search}, 
                    result, 
                    user_input
                )
        
        # Generate final response based on function results
        final_response = self._generate_response(user_input, execution_results, function_calls)
        
        # Log complete interaction
        audit_logger.log_agent_interaction(
            user_input, final_response, execution_results, context
        )
        
        return {
            "status": "success",
            "user_input": user_input,
            "response": final_response,
            "function_calls": execution_results,
            "dry_run": self.dry_run
        }
    
    def _generate_response(self, user_input: str, execution_results: List[Dict], 
                          function_calls: List[Dict]) -> str:
        """Generate human-readable response from function execution results"""
        response_parts = []
        
        for i, result in enumerate(execution_results):
            func_name = result.get("function_name", "unknown")
            func_result = result.get("result", {})
            
            if func_name == "search_patient":
                if func_result.get("status") == "success":
                    patients = func_result.get("patients", [])
                    if patients:
                        response_parts.append(f"Found {len(patients)} patient(s):")
                        for patient in patients:
                            response_parts.append(f"  - {patient.get('name')} (ID: {patient.get('patient_id')})")
                    else:
                        response_parts.append("No patients found matching the search criteria.")
                else:
                    response_parts.append(f"Patient search failed: {func_result.get('message', 'Unknown error')}")
            
            elif func_name == "check_insurance_eligibility":
                if func_result.get("status") == "success":
                    eligibility = func_result.get("eligibility", {})
                    response_parts.append(f"Insurance Status: {eligibility.get('coverage_status', 'Unknown')}")
                    response_parts.append(f"Provider: {eligibility.get('insurance_provider', 'N/A')}")
                    response_parts.append(f"Policy: {eligibility.get('policy_number', 'N/A')}")
                else:
                    response_parts.append(f"Insurance check: {func_result.get('message', 'Not found')}")
            
            elif func_name == "find_available_slots":
                if func_result.get("status") == "success":
                    slots = func_result.get("slots", [])
                    response_parts.append(f"Found {len(slots)} available appointment slot(s):")
                    for slot in slots[:5]:  # Show first 5
                        response_parts.append(
                            f"  - {slot.get('date')} at {slot.get('time')} "
                            f"with {slot.get('provider_name')} ({slot.get('slot_id')})"
                        )
                else:
                    response_parts.append(f"Slot search failed: {func_result.get('message', 'Unknown error')}")
            
            elif func_name == "book_appointment":
                if func_result.get("status") in ["success", "dry_run"]:
                    appointment = func_result.get("appointment", {})
                    if result.get("dry_run"):
                        response_parts.append("DRY RUN MODE: Appointment would be booked as follows:")
                    else:
                        response_parts.append("Appointment booked successfully:")
                    response_parts.append(f"  Appointment ID: {appointment.get('appointment_id')}")
                    response_parts.append(f"  Date: {appointment.get('appointment_date')} at {appointment.get('appointment_time')}")
                    response_parts.append(f"  Provider: {appointment.get('provider_name')}")
                    response_parts.append(f"  Department: {appointment.get('department')}")
                else:
                    response_parts.append(f"Booking failed: {func_result.get('message', 'Unknown error')}")
        
        if not response_parts:
            return "I've processed your request. No specific actions were needed."
        
        return "\n".join(response_parts)
