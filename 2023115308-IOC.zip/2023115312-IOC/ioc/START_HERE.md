# 🚀 Quick Start Guide

## Starting the Application

The Clinical Workflow Automation Agent is now ready to use!

### Start the UI:

```bash
streamlit run app.py
```

The web interface will automatically open in your browser at: **http://localhost:8501**

## Features Available

### ✅ Function Calling Agent
- Natural language understanding of clinical administrative requests
- Automatic function selection and execution
- Multi-step workflow support

### ✅ Available Functions
1. **search_patient(name)** - Search for patients by name
2. **check_insurance_eligibility(patient_id)** - Check insurance coverage
3. **find_available_slots(department)** - Find appointment availability
4. **book_appointment(patient_id, slot_id)** - Book appointments

### ✅ Safety Features
- Medical advice requests are automatically refused
- Input validation against FHIR-style schemas
- Complete audit logging for compliance
- Dry-run mode for safe testing

## Example Queries to Try

1. **Simple patient search:**
   ```
   Search for patient Ravi Kumar
   ```

2. **Complex multi-step request:**
   ```
   Schedule a cardiology follow-up for patient Ravi Kumar next week and check insurance eligibility
   ```

3. **Find appointments:**
   ```
   Find available appointment slots for Cardiology department
   ```

4. **Check insurance:**
   ```
   Check insurance eligibility for patient P12345
   ```

## Mock Data Available

The system includes mock patient data:
- **Patient:** Ravi Kumar (ID: P12345)
- **Patient:** Anita Desai (ID: P12346)
- **Insurance:** Active coverage for P12345

## Configuration

- **Dry-Run Mode:** Toggle in the UI sidebar to simulate actions without execution
- **Audit Logs:** Available in `logs/clinical_agent_audit.log`
- **API Key:** Configured in `config.py` (Hugging Face API)

## Troubleshooting

If the app doesn't start:
1. Ensure all dependencies are installed: `pip install -r requirements.txt`
2. Check that port 8501 is available
3. Verify the Hugging Face API key is valid in `config.py`

## Architecture

- **app.py** - Streamlit web UI
- **clinical_agent.py** - Main agent with function calling logic
- **agent_functions.py** - Function definitions and execution
- **healthcare_api.py** - Mock healthcare APIs with FHIR-style models
- **audit_logger.py** - Compliance logging system
- **config.py** - Configuration settings

Enjoy using the Clinical Workflow Automation Agent! 🏥

