"""
Configuration file for the Clinical Workflow Automation Agent
"""
import os
from dotenv import load_dotenv

load_dotenv()

# Hugging Face API Configuration
HF_API_KEY = "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"
HF_API_URL = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-large"

# Alternative: Use Hugging Face Inference API with a better model for function calling
# Using a model that supports structured outputs
HF_MODEL_NAME = "mistralai/Mistral-7B-Instruct-v0.2"  # Or another model you prefer

# Logging Configuration
LOG_DIR = "logs"
LOG_FILE = "clinical_agent_audit.log"

# API Configuration
API_PORT = 8000
UI_PORT = 8501

# Safety Configuration
DRY_RUN_MODE = False  # Set to True to prevent actual API calls
MAX_RETRIES = 3
