# Clinical Workflow Automation Agent

A function-calling LLM agent designed for clinical workflow automation. This agent acts as an intelligent coordinator that interprets natural-language clinical or operational requests and safely interacts with healthcare APIs to perform validated administrative actions.

## ⚠️ Important Safety Notice

**This agent does NOT provide medical diagnosis or advice.** It is designed exclusively for administrative workflow automation tasks such as:
- Patient lookups
- Appointment scheduling
- Insurance eligibility checks
- Care coordination

## Features

- ✅ **Function Calling**: Deterministic tool execution via structured function schemas
- ✅ **Safety & Validation**: Refuses medical advice requests, validates inputs against schemas
- ✅ **Audit Logging**: Complete audit trail for compliance
- ✅ **Dry-Run Mode**: Test functionality without executing actual API calls
- ✅ **Web UI**: User-friendly Streamlit interface
- ✅ **Multi-Step Workflows**: Handles complex requests requiring multiple function calls

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. The application uses the Hugging Face API key configured in `config.py`. No additional setup needed.

## Usage

### Start the Web UI

```bash
streamlit run app.py
```

The UI will open in your browser at `http://localhost:8501`

### Example Queries

- "Search for patient Ravi Kumar"
- "Schedule a cardiology follow-up for patient Ravi Kumar next week and check insurance eligibility"
- "Find available appointment slots for Cardiology department"
- "Check insurance eligibility for patient P12345"

## Project Structure

```
.
├── app.py                  # Streamlit web UI
├── clinical_agent.py       # Main agent implementation
├── agent_functions.py      # Function definitions and execution
├── healthcare_api.py       # Mock healthcare API functions
├── audit_logger.py         # Audit logging system
├── config.py              # Configuration settings
└── requirements.txt       # Python dependencies
```

## Function Schemas

The agent has access to the following functions:

1. **search_patient(name)**: Search for a patient by name
2. **check_insurance_eligibility(patient_id)**: Check insurance coverage status
3. **find_available_slots(department, start_date, days_ahead)**: Find available appointment slots
4. **book_appointment(patient_id, slot_id, reason)**: Book an appointment

All functions use FHIR-style data models and JSON schemas for validation.

## Audit Logging

All actions are logged to `logs/clinical_agent_audit.log` for compliance and traceability. Each log entry includes:
- Timestamp
- Action type
- Function calls and arguments
- Execution results
- User context

## Dry-Run Mode

Enable dry-run mode in the UI sidebar to simulate actions without actually executing them. This is useful for testing and demonstration purposes.

## Technology Stack

- **LangChain**: Agent framework and tool integration
- **Hugging Face**: LLM inference API
- **Streamlit**: Web UI
- **Pydantic**: Data validation and schema enforcement
- **Python**: Core implementation

## License

This is a proof-of-concept implementation for educational purposes.

