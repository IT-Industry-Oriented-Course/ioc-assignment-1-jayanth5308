"""
Audit logging system for compliance and traceability
"""
import json
import os
from datetime import datetime
from typing import Dict, Any, Optional
from pathlib import Path
from config import LOG_DIR, LOG_FILE


class AuditLogger:
    """Centralized audit logging for all agent actions"""
    
    def __init__(self):
        self.log_dir = Path(LOG_DIR)
        self.log_dir.mkdir(exist_ok=True)
        self.log_file = self.log_dir / LOG_FILE
    
    def log_action(self, action_type: str, details: Dict[str, Any], 
                   user_context: Optional[str] = None):
        """
        Log an action with full context
        
        Args:
            action_type: Type of action (e.g., "function_call", "agent_response", "error")
            details: Action details dictionary
            user_context: Optional user/request context
        """
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action_type": action_type,
            "user_context": user_context,
            "details": details
        }
        
        # Write to log file
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
    
    def log_function_call(self, function_name: str, arguments: Dict[str, Any], 
                         result: Dict[str, Any], user_input: Optional[str] = None):
        """Log a function call execution"""
        self.log_action(
            "function_call",
            {
                "function_name": function_name,
                "arguments": arguments,
                "result": result
            },
            user_context=user_input
        )
    
    def log_agent_interaction(self, user_input: str, agent_response: str, 
                             function_calls: list, user_context: Optional[str] = None):
        """Log a complete agent interaction"""
        self.log_action(
            "agent_interaction",
            {
                "user_input": user_input,
                "agent_response": agent_response,
                "function_calls": function_calls
            },
            user_context=user_context
        )
    
    def log_error(self, error_message: str, context: Dict[str, Any], 
                 user_context: Optional[str] = None):
        """Log an error"""
        self.log_action(
            "error",
            {
                "error_message": error_message,
                "context": context
            },
            user_context=user_context
        )
    
    def get_recent_logs(self, limit: int = 50) -> list:
        """Retrieve recent log entries"""
        if not self.log_file.exists():
            return []
        
        logs = []
        with open(self.log_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines[-limit:]:
                try:
                    logs.append(json.loads(line.strip()))
                except json.JSONDecodeError:
                    continue
        
        return logs


# Global logger instance
audit_logger = AuditLogger()
